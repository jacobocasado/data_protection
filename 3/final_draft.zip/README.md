To launch the program:
    First, create the .jar file by running the script: ./run.sh
    Run the jar file with: java -jar SimpleSec.jar <options>

Created by Jacobo Casado de Gracia and Angel Casanova Bienzobas